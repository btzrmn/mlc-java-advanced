//package oop04.exercise.Telepony;

public interface Callable {
    String call();
}
