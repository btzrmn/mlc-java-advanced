public enum ItemType {
    GOLD,
    GEM,
    CASH
}
