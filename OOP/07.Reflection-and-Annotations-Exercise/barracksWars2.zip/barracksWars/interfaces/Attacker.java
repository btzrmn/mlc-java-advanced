package barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
