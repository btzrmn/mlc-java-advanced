package barracksWars.core;

import barracksWars.interfaces.*;
import barracksWars.interfaces.Runnable;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Engine implements Runnable {

	private CommandInterpreter commandInterpreter;

	public Engine(CommandInterpreter commandInterpreter) {
		this.commandInterpreter = commandInterpreter;
	}

	@Override
	public void run() {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in));
		while (true) {
			try {
				String input = reader.readLine();
				String[] data = input.split("\\s+");
				Executable executable = this.commandInterpreter.interpretCommand(data);
				String result = executable.execute();
				if (result.equals("fight")) {
					break;
				}
				System.out.println(result);
			} catch (RuntimeException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
//
//	private String interpretCommand(String[] data, String commandName) throws ExecutionControl.NotImplementedException {
//		String result = null;
//		String className = Character.toUpperCase(commandName.charAt(0)) + commandName.substring(1) + "Command";
//		try {
//			Class commandClass = Class.forName(COMMAND_PACKAGE_NAME + className);
//			Constructor<Command> commandConstructor =
//					commandClass.getConstructor(String[].class, Repository.class, UnitFactory.class);
//			Command commandObj = commandConstructor
//					.newInstance(data, this.repository, this.unitFactory);
//			result = commandObj.execute();
//		} catch(ClassNotFoundException | NoSuchMethodException e) {
//			e.printStackTrace();
//		} catch (InvocationTargetException e) {
//			e.printStackTrace();
//		} catch (InstantiationException e) {
//			e.printStackTrace();
//		} catch (IllegalAccessException e) {
//			e.printStackTrace();
//		}
//		return result;
//	}
}
