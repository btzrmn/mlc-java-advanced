package barracksWars.interfaces;

public interface CommandInterpreter {

	Executable interpretCommand(String[] data);
}
